<?php
return [
    // +----------------------------------------------------------------------
    // | 内存表设置
    // | 'request_stat' => ['num'=>2048,'fields'=>['ms'=>[\swoole_table::TYPE_INT,4],'count'=>[\swoole_table::TYPE_INT,4]]],
    // +----------------------------------------------------------------------
    //'request_stat' => ['num'=>2048,'fields'=>['ms'=>swoole_table::TYPE_INT,'count'=>swoole_table::TYPE_INT]], 此table 内置
    //'workers_stat' => ['num'=>2048,'fields'=>['ms'=>swoole_table::TYPE_INT,'count'=>swoole_table::TYPE_INT]], 此table 内置
    //'auth' => ['num' => 8192, 'fields' => ['is_login' => [\swoole_table::TYPE_INT, 2], 'is_auth' => [\swoole_table::TYPE_INT, 2]],

    //'agent_id_name' => ['num' =>204800, 'fields' => ['last_at' => [\swoole_table::TYPE_INT, 4],]],
    //'ws_fd_uid' => ['num' => 1024000, 'fields' => ['workerid' => [\swoole_table::TYPE_INT, 4],]],
    //'ws_uid_fd' => ['num' => 2048, 'fields' => ['last_at' => [\swoole_table::TYPE_STRING, 4],]],
    ];

?>